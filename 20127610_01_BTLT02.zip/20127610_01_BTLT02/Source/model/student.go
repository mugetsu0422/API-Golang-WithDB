package model

type Students struct {
	Id int `json:"id"`
	Name string `json:"name"`
}
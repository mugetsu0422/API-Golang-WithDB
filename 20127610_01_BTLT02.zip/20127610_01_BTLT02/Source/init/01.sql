create table student (
    id int, 
    name varchar(255)
);

insert into student(id, name) values
(1, 'A'),
(2, 'B'),
(3, 'C')